function ready() {
        var imageWidth = 1000;
  var imageHeight = 1000;
  function slider(element) {
    return document.createElement(element);
}
function append(parent, el) {
    return parent.appendChild(el);
}
    for (r = 101; r < 116; r++) {
        
        fetch('https://i.picsum.photos/id/' + r + '/' + imageWidth + '/' + imageHeight + '.jpg')
            .then((response) => {
                var responseImages = document.getElementById("vanilla-slider");
                var creatediv = slider('div');
                var img = slider('img');
                img.setAttribute('src', response.url);
                append(creatediv, img);
                append(responseImages, creatediv);
            })

    }
    setTimeout(function () {
        var slidesList = document.querySelector('.slider-items').children;
        var nextslide = document.querySelector(".next");
        var prevslide = document.querySelector(".prev");
        var imageSlide = 0;
        slidesList[imageSlide].classList.add("active");
        var NumberOfSlides = slidesList.length;

        nextslide.onclick = function () {
            next("next");
        }
        prevslide.onclick = function () {
            next("prev");
        }
        function next(direction) {

            if (direction == "next") {
                imageSlide++;
                if (imageSlide == NumberOfSlides) {
                    imageSlide = 0;
                }

            }
            else {
                if (imageSlide == 0) {
                    imageSlide = NumberOfSlides - 1;
                }
                else {
                    imageSlide--;
                }
            }
            for (let i = 0; i < NumberOfSlides; i++) {
                slidesList[i].classList.remove('active');
            }
            slidesList[imageSlide].classList.add("active");

        }

    }, 500);



}
document.addEventListener("readystatechange", ready);






